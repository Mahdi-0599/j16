from .AlexNet import AlexNet
from .FakeFaceNet import FakeNet
from .VGG import VGGNet
from .DiscNet import DiscNet
from .MobileNet import MobileNetV2

